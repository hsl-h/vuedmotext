# Blockchain Visualization Instructions

## 1. Start the Backend

Open a terminal and run:

```bash
cd blockchaindemo
npm start
```

In the blockchain CLI, start the API server:

```bash
blockchain>>>>>>>>> api 3001
```

You should see `Listening http on port: 3001`.

## 2. Start the Frontend

Open a **new** terminal and run:

```bash
cd frontend
npm run dev
```

Open the URL shown (usually `http://localhost:5173`) in your browser.

## 3. Interact

In the backend CLI, mine a new block:

```bash
blockchain>>>>>>>>> mine "Hello Blockchain"
```

Watch the frontend! The new block will appear automatically within 2 seconds.
